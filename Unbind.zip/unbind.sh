#!/bin/bash
python3 unbind.py